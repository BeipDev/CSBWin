How to start a new original Dungeon Master game:

  Just launch CSBWin.exe and enter the dungeon

How to start a new Chaos Strikes Back (CSB) game:

  Run 'Start new CSB Game.bat' and enter the dungeon
  Choose your champions and then save your game
  Launch CSBWin.exe and choose 'Utility' on the main screen
  Use 'Make New Adventure' (it's safe to replace your original save game)
  Then launch CSBWin.exe and load your game


